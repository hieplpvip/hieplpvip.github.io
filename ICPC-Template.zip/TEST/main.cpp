#include <bits/stdc++.h>
#define TASKNAME "A"
using namespace std;
using ll = long long;
const int NTEST = 10;

mt19937_64 rng(chrono::high_resolution_clock::now().time_since_epoch().count());
ll Rand(ll low, ll high) {
  return uniform_int_distribution<ll>(low, high)(rng);
}

int main() {
  for (int ITEST = 1; ITEST <= NTEST; ++ITEST) {
    ofstream inp(TASKNAME".inp");

    inp.close();

    system(TASKNAME".exe");
    system(TASKNAME"_trau.exe");
    if (system("fc " TASKNAME ".out " TASKNAME ".ans") != 0) {
      cout << "TEST " << ITEST << ": WRONG!!!\n";
      return 1;
    }
    cout << "TEST " << ITEST << ": CORRECT\n";
  }
  return 0;
}

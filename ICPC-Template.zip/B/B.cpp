//#pragma GCC optimize("Ofast")
//#pragma GCC target("avx2")
#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define uniq(x) x.resize(unique(all(x)) - x.begin())
#define pb push_back
#define emb emplace_back
using ull = unsigned long long;
using ll = long long;
using pii = pair<int, int>;
using vi = vector<int>;

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
}
